#include "read.h"

int check_url(const char *str_check){
	int err;
			regex_t preg;
			const char *str_regex = "[-_[:alnum:]]+\.txt";
			err = regcomp (&preg, str_regex, REG_NOSUB | REG_EXTENDED);

			if(err == 0)
			{

			 	int match = regexec(&preg,str_check,0,NULL,0);
			 	regfree(&preg);

			 	if(match == 0)
			 	{
			 		return 0;
			 	}
			 	else
			 	{
			 		return 1;
			 	}
			 }
			else{
			
			return 1;
		}
		return 0;

}

void insert(Sommet *s1,Sommet *s2){
	if(s1->pred == NULL){
		s1->pred = s2;
	}else{
		Sommet *tmp = s1->pred;
		

		while(tmp->pred != NULL){
			tmp = tmp->pred;
		}
		tmp->pred = s2;
		
			}
}

//assignation des sommets predecesseurs au sommet
void read_txt(double *f_t,Sommet *tabSommet,int sommet,FILE *F,int *liste_succ)
{
	int n;
	int numsommet,nbrsucc,num;

	double prob;
	 for(int i = 0; i< sommet; i++){
	 	Sommet *tmp = malloc(sizeof(Sommet));
	 	tmp->val = i+1;
	 	tmp->pred = NULL;
	 	tabSommet[i] = *tmp;

	 }

	 for(int i = 0; i < sommet; i ++)
	 {

		char *ctmp = malloc (262144);
		char *memCtmp = ctmp;
	 	fgets(ctmp,262144,F);
	
	 	sscanf(ctmp,"%d %d %n",&numsommet,&nbrsucc,&n);
		//free(ctmp);
	 	//printf("nums = %d,nbrsucc = %d\n",numsommet,nbrsucc);
	 	liste_succ[i] = nbrsucc;
	 	//ctmp += n;

	 	
	 	if(nbrsucc ==0)
	 	{
	 		f_t[i] = 1.0;
	 		free(memCtmp);
	 		continue;
	 	}else
	 	{
	 		f_t[i] = 0.0;
	 	}


	 	//Etape 3
	 	for(int j = 0; j < nbrsucc;j++)
	 	{
	 		sscanf(ctmp," %d %lf %n",&num,&prob,&n);
	 			//printf("num = %d prob = %lf\n ",num,prob);

	 			if( (num <= sommet) )
	 			{
	 				Sommet *atmp = malloc(sizeof(Sommet));
	 				atmp->cout = prob;
	 				atmp->val = i+1;
	 				atmp->pred = NULL;
	 				insert(&tabSommet[num-1],atmp);
	 				//free(atmp);
	 			}
	 				ctmp += n;
	 	}
	 	free(memCtmp);
	 	//printf("ctmp = %d\n",n);
	 	//printf("\n");
	 	
	 }

}


//verification de convergence par comparaison du vecteur n-1 et n
int compare(double *x1,double *x2,int taille,double precision){
	for(int i = 0;i<taille;i++){
		if(fabs(x1[i]-x2[i]) >= precision ){
			return 1;
		}
	}
	return 0;
}


